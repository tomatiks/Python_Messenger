{
    "startline":{
        "method":"GET",
        "code":200,
        "version":"HTTP/1.1"
    },
    "headers":{
        "date": "Wed, 11 Feb 2009 11:20:59 GMT",
        "server": "SocketServer",
        "content_type": "text/plain; charset=utf-8",
        "content_language": "ru",
        "last_modified": "Wed, 11 Feb 2009 11:20:59 GMT"
    },
    "body":"Some response message text"
}
