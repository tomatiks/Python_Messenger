{
    "startline":{
        "method":"GET",
        "uri":"localhost:8000/echo",
        "version":"HTTP/1.1"
    },
    "headers":{
        "host": "localhost",
        "accept": "text/plain",
        "user_agent": "python client"
    },
    "body":"Some request message text"
}
