# Версия HTTP протокола
VERSION = 'HTTP/1.1'

# Кодировка по умолчанию
ENCODING = 'utf-8'
